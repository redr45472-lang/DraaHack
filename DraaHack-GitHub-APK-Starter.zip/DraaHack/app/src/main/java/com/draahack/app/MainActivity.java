package com.draahack.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_SCREEN_CAPTURE = 4102;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new DraaHackBridge(), "DraaHack");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class DraaHackBridge {
        @JavascriptInterface
        public void requestScreenPermission() {
            runOnUiThread(() -> {
                MediaProjectionManager manager =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                if (manager != null) {
                    startActivityForResult(
                        manager.createScreenCaptureIntent(),
                        REQUEST_SCREEN_CAPTURE
                    );
                } else {
                    Toast.makeText(MainActivity.this,
                        "Izin berbagi layar tidak tersedia.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void stopSession() {
            runOnUiThread(() -> Toast.makeText(
                MainActivity.this,
                "Sesi dihentikan. Belum ada streaming aktif.",
                Toast.LENGTH_LONG
            ).show());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this,
                    "Izin diberikan. Streaming belum diimplementasikan.",
                    Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this,
                    "Izin berbagi layar ditolak.",
                    Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
