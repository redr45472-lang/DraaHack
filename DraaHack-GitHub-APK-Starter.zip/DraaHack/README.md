# DraaHack — starter Android project

Starter project for a consent-based Android companion dashboard.

## Build APK using GitHub Actions

1. Upload all files and folders in this repository to a new GitHub repository.
2. Open **Actions** and run **Build DraaHack APK**, or push a commit to `main`.
3. When the workflow succeeds, open the workflow run and download the `DraaHack-debug-apk` artifact.
4. Extract the ZIP artifact to obtain `app-debug.apk`.

## Important limitations

This is only a starter APK/dashboard. It does **not** include a pairing server, server-issued pairing codes, live screen streaming, WebRTC signaling, or remote touch control. The screen permission button only asks Android for user consent and then reports that streaming is not implemented.

For real device-to-device features, add a secure backend and implement the Android MediaProjection foreground-service lifecycle and a secure, consent-based streaming/signaling design. Do not use this app to access a device without the owner's explicit permission.

## Local build

Requires JDK 17, Android SDK platform 35/build-tools 35.0.0, and Gradle 8.9:

```bash
gradle assembleDebug
```

The APK output is `app/build/outputs/apk/debug/app-debug.apk`.
